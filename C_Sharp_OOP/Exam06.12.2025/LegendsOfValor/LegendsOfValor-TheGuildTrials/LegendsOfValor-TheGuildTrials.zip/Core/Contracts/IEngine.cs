﻿namespace LegendsOfValor_TheGuildTrials.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
